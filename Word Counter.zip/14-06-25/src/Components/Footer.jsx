import React from 'react'

export default function Footer(props) {
    return (
        <footer className="py-4 mt-5 bg-dark text-light">
            <div className="container">
                <div className="row">
                    <div className="col-md-6 text-center text-md-start">
                        <h5 className="mb-3">DevAnsh</h5>
                        <p className="mb-0">A powerful text utility application to help you analyze and transform your text efficiently.</p>
                    </div>
                    <div className="col-md-6 text-center text-md-end mt-3 mt-md-0">
                        <h5 className="mb-3">Connect With Us</h5>
                        <div className="social-links">
                            <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="text-decoration-none me-3 text-light">
                                <i className="fab fa-github fa-lg"></i>
                            </a>
                            <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="text-decoration-none me-3 text-light">
                                <i className="fab fa-linkedin fa-lg"></i>
                            </a>
                            <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-decoration-none me-3 text-light">
                                <i className="fab fa-twitter fa-lg"></i>
                            </a>
                            <a href="mailto:contact@example.com" className="text-decoration-none text-light">
                                <i className="fas fa-envelope fa-lg"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <hr className="my-4 border-light" />
                <div className="row">
                    <div className="col-12 text-center">
                        <p className="mb-0">
                            &copy; {new Date().getFullYear()} DevAnsh. All rights reserved.
                        </p>
                    </div>
                </div>
            </div>
        </footer>
    )
} 