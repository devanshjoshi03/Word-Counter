import React from 'react'

export default function About(props) {

    // const [myStyle, setMyStyle] = useState({
    //     color: 'black',
    //     backgroundColor: 'white'
    // }) 
    let myStyle = {
        color: props.mode ==='dark'?'white':'#042743',
        backgroundColor: props.mode ==='dark'?'rgb(36 74 104)':'white', 
    }
    
    return (
        <div className="container">
            <h1 className="my-4 text-center" style={{color: props.mode ==='dark'?'white':'#042743'}}>About TextUtils</h1>
            <div className="accordion shadow-sm" id="accordionExample">
                <div className="accordion-item">
                    <h2 className="accordion-header" id="headingOne">
                    <button className="accordion-button" type="button" style={myStyle} data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                    <strong><i className="fas fa-magic me-2"></i>Powerful Text Analysis</strong>
                    </button>
                    </h2>
                    <div id="collapseOne" className="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                    <div className="accordion-body" style={myStyle}>
                        TextUtils provides a comprehensive suite of text manipulation tools to help you analyze and transform your text efficiently. From basic operations like case conversion to advanced features like word count and reading time estimation, TextUtils has everything you need to work with text effectively.
                    </div>
                    </div>
                </div>
                <div className="accordion-item">
                    <h2 className="accordion-header" id="headingTwo">
                    <button className="accordion-button collapsed" style={myStyle} type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                    <strong><i className="fas fa-gift me-2"></i>Free & Easy to Use</strong>
                    </button>
                    </h2>
                    <div id="collapseTwo" className="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                    <div className="accordion-body" style={myStyle}>
                        TextUtils is completely free to use and requires no registration. Our intuitive interface makes it easy for anyone to get started. Whether you're a student, professional, or casual user, you'll find TextUtils to be an invaluable tool for your text processing needs.
                    </div>
                    </div>
                </div>
                <div className="accordion-item">
                    <h2 className="accordion-header" id="headingThree">
                    <button className="accordion-button collapsed" style={myStyle} type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                    <strong><i className="fas fa-globe me-2"></i>Universal Compatibility</strong>
                    </button>
                    </h2>
                    <div id="collapseThree" className="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                    <div className="accordion-body" style={myStyle}>
                        TextUtils works seamlessly across all modern web browsers and devices. Whether you're using Chrome, Firefox, Safari, or any other browser, you can access TextUtils from your desktop, tablet, or mobile device. Your text processing needs are covered, no matter where you are.
                    </div>
                    </div>
                </div>
            </div>

        </div>
    )
}
